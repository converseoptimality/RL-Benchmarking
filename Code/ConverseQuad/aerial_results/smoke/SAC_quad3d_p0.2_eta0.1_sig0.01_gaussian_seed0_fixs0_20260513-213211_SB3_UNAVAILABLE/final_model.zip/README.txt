SB3/Torch was unavailable; this is a zero-action placeholder artifact for smoke workflows.
